import React, {Component} from 'react';

export default
class ActiveUser extends Component{
    
    render(){
        
        let user = this.props.user;
                                        let mode = this.props.filterMode;
                                        let by = this.props.filterBy;
        
        if(!user){
            return (
                <div className='col-sm-4 col-md-3 col-lg-2' >
                    <h3>Данные не найдены!</h3>
                </div>
            )
        }
        
        return (
            <div className='col-sm-4 col-md-3 col-lg-2' >
                <div className="thumbnail">
                    <img width="100pt" src={`images/${user.image}.svg`}/>
                    <div className="thumbnail-caption">
                        <h3>{this.props.user.name}</h3>
                        <table className="user-info table table-responsive">
                            <tbody>
                                <tr>
                                    <td>Цена:</td>
                                    <td>{user.age}</td>
                                </tr>
                                <tr>
                                    <td>Количество:</td>
                                    <td>{user.phone}</td>
                                </tr>
                                <tr>
                                    <td>Телефон:</td>
                                    <td>{`8 ${user.image}`}</td>
                                </tr>
                            </tbody>
                        </table>
                        <p><b>Любая фраза:</b> {user.phrase}</p>
                        <button className="btn btn-default" onClick={ () => this.props.deleteID(user.id)}>
                            <i className={"icon fa fa-trash"}></i> Удалить
                        </button>
                        <button className="btn btn-default" onClick={ () => this.props.copyID(user.id)}>
                            <i className={"icon fa fa-copy"}></i> Копировать
                        </button>
                    </div>
                </div>
            </div>
        );
    }
    
}