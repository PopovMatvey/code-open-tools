import React, {Component} from 'react';

export default 
class UserData extends Component{
    
    render(){
        return (
            <tr onClick={ () => {this.props.setActiveUser(this.props.user.id)} } >
                <td><img width="30%" src={`images/${this.props.user.image}.svg`} className="user-image"/></td>
                <td>{this.props.user.name}</td>
                <td>{this.props.user.age}</td>
                <td>{this.props.user.phone}</td>
            </tr>
        );
    }
    
}
    
  
        
