import React, { Component } from 'react';

import SearchBar    from './Components/SearchBar';
import ToolBar      from './Components/ToolBar';
import UserList     from './Components/UserList';
import ActiveUser   from './Components/ActiveUser';

export default
class ShowListsApp extends Component {
    
    constructor(props) {
        super(props);
        this.state = {
            activeUserId: 0,
            filterText: '',
            filterMode: '',
            filterBy: '',
            myUsers: this.props.appData
        };
    }
    
    setFilterString(event) {
        this.setState({
            filterText: event.target.value
        })
    }

    deleteID(prop){
        let myUsersTmp = this.props.appData
        const index = myUsersTmp.findIndex(n => n.id === prop);
        if (index !== -1) {
            myUsersTmp.splice(index, 1)
        }
        // Не знаю почему, но при изменении myUsers изменяется также appData         
        this.setState({myUsers: myUsersTmp});
    }

    copyID(prop){
        let myUsersTmp = this.state.myUsers;
        const index = myUsersTmp.findIndex(n => n.id === prop);
        if (index !== -1) {
            myUsersTmp.splice(index, 0, 
                {
                  id: Math.ceil(Math.random(1000)*10000), // Надо вытянуть из битрикса, данные должны быть уникальными!
                  name: myUsersTmp[index].name,
                  age: Math.ceil(Math.random(1000)*10000) + "." + Math.ceil(Math.random(1000)*100) + " руб.",
                  phone: Math.ceil(Math.random(1000)*10),
                  image: "5",
                  phrase: "12321",
                  section: "13"
                }
              );
        }
        // Не знаю почему, но при изменении myUsers изменяется также appData         
        this.setState({myUsers: myUsersTmp});
    }

    setFilterMode(prop){
        if(this.state.filterBy === prop){
            this.setState({
                filterMode: this.state.filterMode === 'asc' ? 'desc' : 'asc'
            })
        }else{
            this.setState({
                filterMode: 'asc',
                filterBy: prop
            })
        }
    }
    
    setActiveUser(key){
        this.setState({
            activeUserId: key
        })
    }
    
    filterUsers(){
       //let users = this.props.appData;
       let users = this.state.myUsers;
        
        if(this.state.filterText.length){
            users = users.filter((user) => {
                return user.name.search( new RegExp( this.state.filterText, "i")) !== -1;
            });
        }
        
        if(this.state.filterBy.length || this.state.filterMode.length){
            users.sort((a, b) => {
                if(a[this.state.filterBy] < b[this.state.filterBy]){
                    return this.state.filterMode === 'asc' ? -1 : 1;
                }
                if(a[this.state.filterBy] > b[this.state.filterBy]){
                    return this.state.filterMode === 'asc' ? 1 : -1;
                }
                return 0;
            });
        }
        
        return users;
    }
    
    getActiveUser(users){
        let user = users.filter((user) => {
            return (user.id === this.state.activeUserId);
        });
        return user[0] || users[0];
    }
    
    render() {
        
        let users = this.filterUsers();
        let user = this.getActiveUser(users);
        
        return (
            <div className="container-fluid app">
                <SearchBar filterText={this.state.filterText} setFilterString={this.setFilterString.bind(this)} />
                <ToolBar filterBy={this.state.filterBy} filterMode={this.state.filterMode} setFilterMode={this.setFilterMode.bind(this)}/>
                <div className="row">
                    <UserList users={users} setActiveUser={this.setActiveUser.bind(this)} />
                    <UserList users={users} setActiveUser={this.setActiveUser.bind(this)} />
                    <ActiveUser user={user} deleteID={this.deleteID.bind(this)} copyID={this.copyID.bind(this)}/>
                </div>
            </div>
        );
    }
}
