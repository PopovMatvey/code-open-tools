import React, { useState } from 'react';
import BX24API from './Bitrix24/bx24';

export const AddTask = () => {
  const [taskData, setTaskData] = useState({
    title: '',
    description: '',
  });
  console.log('🚀 ~ file: AddTask.jsx ~ line 6 ~ AddTask ~ taskData', taskData);

  const onChange = (event) => {
    setTaskData({
      ...taskData,
      [event.target.name]: event.target.value,
    });
  };

  const onSubmit = async (event) => {
    event.preventDefault();
    console.log('Начал думать');
    const result = await BX24API.callMethod('tasks.task.add', {
      fields: {
        TITLE: taskData.title,
        DESCRIPTION: taskData.description,
        RESPONSIBLE_ID: 1,
      },
    });

    console.log('result = ', result);
  };

  return (
    <div>
      <form onSubmit={onSubmit}>
        <input
          type='text'
          name='title'
          value={taskData.title}
          onChange={onChange}
        /><label>Название задачи</label>
        <input
          type='text'
          name='description'
          value={taskData.description}
          onChange={onChange}
        /><label>Описание задачи</label>
        <button type='submit'>Добавить задачу</button>
      </form>
    </div>
  );
};

// import React, { useState } from 'react';
// import BX24API from './Bitrix24/bx24';

// export const AddTask = () => {
//   const [taskData, setTaskData] = useState({
//     title: '',
//     description: '',
//   });
//   console.log('🚀 ~ file: AddTask.jsx ~ line 6 ~ AddTask ~ taskData', taskData);

//   const onChange = (event) => {
//     setTaskData({
//       ...taskData,
//       [event.target.name]: event.target.value,
//     });
//   };

//   const onSubmit = async (event) => {
//     event.preventDefault();
//     console.log('Начал думать');
//     const result = await BX24API.callMethod('tasks.task.add', {
//       fields: {
//         TITLE: taskData.title,
//         DESCRIPTION: taskData.description,
//         RESPONSIBLE_ID: 1,
//       },
//     });

//     console.log('result = ', result);
//   };

//   return (
//     <div>
//       <form onSubmit={onSubmit}>
//         <h1>Сфотографируйте QR-код или выберите из медиатеки:</h1>
//         <br></br>
//         {/* <label htmlFor="file">Сфотографируй QR-код</label> */}
//         <input type="file" name="object-photo" accept="image/*" capture="camera"  alt="Сфотографируй QR-код"></input>
//         <input type="file"  name="object-photo1" accept="image/*;capture=camera"></input>
//         <input type="file" accept="image/*" capture></input>
//         <input type="file" id="myinput" accept="image/*;capture=camera" capture></input>
//         <input type="file" id="capture" accept="image/*, video/*, audio/*" capture/>
//         <input type="file" accept="image/*" capture="camera" />
//         <br></br>
//         <br></br>
//         <br></br>
//         <button type='submit'>Отправить на обработку</button>
//         {/* <input
//           type='text'
//           name='title'
//           value={taskData.title}
//           onChange={onChange}
//         />
//         <input
//           type='text'
//           name='description'
//           value={taskData.description}
//           onChange={onChange}
//         />
//         <button type='submit'>Добавить задачу</button> */}
//       </form>
//     </div>
//   );
// };


