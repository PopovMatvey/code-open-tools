import React, { useState } from 'react';
import BX24API from './Bitrix24/bx24';

export const AddElemsList = () => {
 // Функция
 const add = async () => {
  console.log('Началось добавление...')
    // // Создание элементов списка в определенном разделе
    // // Правильный пример массива, созданный в цикле
    // let comandCycl = {};
    // let listID = 25;    // ID списка
    // let sectionID = 9;  // ID раздела
    // for (let i = 1; i < 1056; i++){
    //   // Команда создаёт элемент списка в нужном разделе
    //   comandCycl[i] = 'lists.element.add?IBLOCK_TYPE_ID=lists&IBLOCK_ID=' 
    //   + listID + '&ELEMENT_CODE=Элемент ' + i + '&FIELDS[NAME]=Элемент ' 
    //   + i + '&FIELDS[IBLOCK_SECTION_ID]=' + sectionID;
    // }
    //   const result = await BX24API.batchMethod(comandCycl);
    //   console.log(result)


    // // Пример чтения всех элементов списка в определенном разделе
    // const result = await BX24API.getAll('lists.element.get', {
    //   IBLOCK_TYPE_ID: 'lists',
    //   IBLOCK_ID: 25,
    //   FIELDS: {
    //     IBLOCK_SECTION_ID: 9
    //   }
    // });
    // console.log(result) 

    // Создание заданного количества элементов в нужном списке нужного раздела
    let comandCycl = {};
    for (let i = 0; i < AddElemsList.NUMBER; i++){
      // Команда создаёт элемент списка в нужном разделе
      comandCycl[i] = 'lists.element.add?IBLOCK_TYPE_ID=lists&IBLOCK_ID=' 
      + AddElemsList.IBLOCK_ID + '&ELEMENT_CODE=Элемент списка ' + AddElemsList.IBLOCK_ID
      + ' раздела ' + AddElemsList.IBLOCK_SECTION_ID
      + ' №' + (i + 1) + '&FIELDS[NAME]=Элемент списка ' + AddElemsList.IBLOCK_ID
      + ' раздела ' + AddElemsList.IBLOCK_SECTION_ID + ' №'+
      + (i + 1) + '&FIELDS[IBLOCK_SECTION_ID]=' + AddElemsList.IBLOCK_SECTION_ID;
    }
      const result = await BX24API.batchMethod(comandCycl);
      console.log(result)
  };

  const [AddElemsList, setAddElemsList] = useState({
    IBLOCK_ID: '',
    IBLOCK_SECTION_ID: '',
    NUMBER: ''
  });

  const onChange = (event) => {
    setAddElemsList({
      ...AddElemsList,
      [event.target.name]: event.target.value,
    });
  };
  // Добавить бы на форме надписи, типа начало добавления и когда закончится
  return (
    <div>
      <form>
        <div>
          <p>Введите IBLOCK_ID списка: </p>
          <input type='text' name='IBLOCK_ID' value={AddElemsList.IBLOCK_ID} onChange={onChange}/>
        </div>
        <div>
          <p>Введите IBLOCK_SECTION_ID списка: </p>
          <input type='text' name='IBLOCK_SECTION_ID' value={AddElemsList.IBLOCK_SECTION_ID}  onChange={onChange}/>
        </div>   
        <div>
          <p>Введите количество элементов списка: </p>
          <input type='text' name='NUMBER' value={AddElemsList.NUMBER}  onChange={onChange}/>
        </div> 
        <div><p></p></div>     
      </form>
      <button onClick={add}>Добавить элементы в список</button>
    </div>
  );
};



