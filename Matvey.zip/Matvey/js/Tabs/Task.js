import React from 'react';
import styles from './styles'
import { AddTask } from '../AddTask';

const About = () => {
  return (
    <div style={styles}>
      <AddTask />
    </div>
  )
}

export default About