import React        from 'react';
import ShowListsApp from '../ShowListsApp'
import BX24API      from '../Bitrix24/bx24';
import Preloader    from '../Components/Preloader';

const {useState, useEffect} = React;

async function myAsyncFunction() {
  try {
    const response = await BX24API.getAll('lists.element.get', {IBLOCK_TYPE_ID: 'lists', IBLOCK_ID: '35'});//, FILTER: {SECTION_ID: '13'}});
    if (response.lenght != 0) {
      return await response;
    } else {
      console.log("Can't get data");
    }
  } catch (e) {
    console.log(e);
  }


  // // Получаем названия всех списков
  // const myPromiseSections = new Promise(function(resolve){
  //   const my_GetLists = BX24API.callMethod('lists.get', {IBLOCK_TYPE_ID: 'lists'});
  //   resolve(my_GetLists)
  // })

  // console.log('Названия разделов: ')
  // myPromiseSections.then(function(value2){
  //   for (let i = 0; i < value2.result.length; i++) {
  //     console.log('Раздел №', + i + ' : ', value2.result[i].NAME);
  //   }
  // })

  // // Получаем элементы определенного списка в нужном разделе
  // const myPromiseSection = new Promise(function(resolve){
  //   const my_GetListSection = BX24API.getAll('lists.element.get', {IBLOCK_TYPE_ID: 'lists', IBLOCK_ID: '25'})
  //   //FILTER: {SECTION_ID: '9'} // можно передать фильтрацию по разделам
  //   resolve(my_GetListSection)
  // })
  // return myPromiseSection
  //return BX24API.getAll('lists.element.get', {IBLOCK_TYPE_ID: 'lists', IBLOCK_ID: '25'})
}

function myApp() {
  const [outData, getData] = useState([
    {
      "id": "",
      "name": "",
      "age": "",
      "phone": "",
      "image": "",
      "phrase": "",
      "section": ""
    }
  ]);
  
  useEffect(() => {
    async function getListFromBitrix() {
      const data = await myAsyncFunction();
      const my_data =  [
        {
          "id": "",
          "name": "",
          "age": "",
          "phone": "",
          "image": "",
          "phrase": "",
          "section": ""
        }
      ]
      for (let i = 0; i < data.total; i++){
        my_data[i] = {
          "id": data.result[i].ID,
          "name": data.result[i].NAME,
          "age": Math.ceil(Math.random(1000)*10000) + "." + Math.ceil(Math.random(1000)*100) + " руб.",
          //"phone": Math.ceil(Math.random(1000)*10),
          "phone": Math.ceil(Math.random(1000)*10),
          "image":  Math.ceil(Math.random(10)*12),
          "phrase": "",
          "section": data.result[i].IBLOCK_SECTION_ID
        }
      }
      getData(my_data);
    }   
    getListFromBitrix();
  }, [])

  if (outData[0].id == "") {
    return (
      <div>
        <p></p>
        <Preloader/>
      </div>
    )
  }
  else {
    return (
      <div>
        <p></p>
        <ShowListsApp appData = {outData}/>
      </div>
    );
  }
}
export default myApp