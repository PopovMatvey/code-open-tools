import React from 'react';
import styles from './styles'
import { MySmartDigital } from '../mySmartDigital';
import DropdownHOC from "../DpopdownTreeSelect/DropdownHOC";
import { useState } from 'react';
// const styles = {
//   fontFamily: 'sans-serif',
//   backgroundColor: '#eee',
// }

let data = [
  {
    "label": "Обрезка баннера по периметру",
    "children": [
      {
        "label": "Доп. параметры",
        "children": [
          {
            "label": "Доп. параметр 1"
          },
          {
            "label": "Доп. параметр 2"
          },
          {
            "label": "Доп. параметр 3"
          }
        ]
      }, 
    ]
  },
  {
    "label": "Подготовка к печати",
    "children": [
      {
        "label": "Доп. параметр 1"
      },
      {
        "label": "Доп. параметр 2"
      }
    ]
  },
  {
    "label": "Склейка баннеров",
    "children": [
      {
        "label": "Доп. параметр 1"
      },
      {
        "label": "Доп. параметр 2"
      },
      {
        "label": "Доп. параметр 3"
      },
      {
        "label": "Доп. параметр 4"
      }
    ]
  },
  {
    "label": "Подклейка периметра",
    "children": [
      {
        "label": "Доп. параметр 1"
      },
      {
        "label": "Доп. параметр 2"
      },
      {
        "label": "Доп. параметр 3"
      }
    ]
  },
  {
    "label": "Установка люверсов",
    "children": [
      {
        "label": "Доп. параметр 1"
      },
      {
        "label": "Доп. параметр 2"
      }
    ]
  }
];
// const [myOnChange, setMyOnChange] = useState({
//   title: ''
// });
// const getMyOnChange = (event) => {
//   console.log('ЭЭЭЭЭВЕЕЕЕНТТТТТТТТТТТ!!!!!!!!!!!!!!!!!!')
//   setMyOnChange({
//     ...myOnChange,
//     [event]: event,
//   });
// };
// const myOnChange = (currentNode) => {
//   console.log('onChange::', currentNode)
// }

// const obj = new DropdownHOC(data={data});
// console.log(obj.method1);

const About = () => {
  return (
    <div style={styles}>
      {/* <h1>Тут будут мои умные цифры</h1> */}
      <MySmartDigital />
      <DropdownHOC data={data} />
    </div>
  )
}

export default About