import React from 'react';
import styles from './styles'
import { AddElemsList } from '../AddElemsList';

// const styles = {
//   fontFamily: 'sans-serif',
//   backgroundColor: '#eee',
  
// }

const Info = () => {
  return (
    <div style={styles}>
      <h1>Добавление элементов списка</h1>
      <AddElemsList />
    </div>
  )
}

export default Info