import React from 'react'
import { Tabs, TabList, TabPanel, Tab } from 'react-re-super-tabs'
import CustomTab from './CustomTab'
import AddElemsList from './AddElemsList'
import ShowLists from './ShowLists'
import Task from './Task'

const myTabs = () => (
  <div>
    <Tabs activeTab='AddElemsList'>
      <TabList>
        <Tab component={CustomTab} label='Добавить элементы в список' id='AddElemsList' />
        <Tab component={CustomTab} label='Добавить задачу' id='Task' />
        <Tab component={CustomTab} label='Показать списки' id='ShowLists' />
      </TabList>
      <TabList>
        <TabPanel component={AddElemsList} id='AddElemsList' />
        <TabPanel component={Task} id='Task' />
        <TabPanel component={ShowLists} id='ShowLists' />
      </TabList>
    </Tabs>
  </div>
)

export default myTabs